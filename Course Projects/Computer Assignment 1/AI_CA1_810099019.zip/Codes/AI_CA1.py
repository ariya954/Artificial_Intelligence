from enum import Flag, auto
from dataclasses import dataclass
from typing import Any, Callable, List, Dict, Set, Tuple, Union

INPUT = 'Inputs/input_0.txt'

@dataclass
class Edge:
    dst: int
    weight: int
    last_crossing_time = 0
    time_between_two_crossings = 0


class NodeType(Flag):
    NORMAL = auto()
    DEVOTEE = auto()
    RECIPE = auto()
    HARD = auto()


@dataclass
class Node:
    adj: List[Edge]
    type: NodeType


class Graph:
    def __init__(self, n: int):
        self.time = 0
        self.nodes = [Node([], NodeType.NORMAL) for _ in range(n)]
        self.hard_nodes: Set[int] = set()
        self.recipes: Set[int] = set()
        self.devotee_recipes: Dict[int, set[int]] = {}

    def add_edge(self, u: int, v: int, weight: int):
        self.nodes[u].adj.append(Edge(v, weight))
        self.nodes[v].adj.append(Edge(u, weight))

    def setas_loose_edge(self, list_of_edges: List[Union[int, int]], edge_index: int, t: int):
        for edge in self.nodes[list_of_edges[edge_index][0]].adj:
            if edge.dst == self.nodes[list_of_edges[edge_index][1]]:
                edge.time_between_two_crossings = t
        for edge in self.nodes[list_of_edges[edge_index][1]].adj:
            if edge.dst == self.nodes[list_of_edges[edge_index][0]]:
                edge.time_between_two_crossings = t

    def set_devotee_proirities(self, devotee_proirities: List[Union[int, int]]):
        self.devotee_proirities = devotee_proirities

    def add_devotee(self, u: int, recipes: List[int]):
        self.nodes[u].type &= ~NodeType.NORMAL
        self.nodes[u].type |= NodeType.DEVOTEE
        recipes_set = set(recipes)
        self.devotee_recipes[u] = recipes_set
        self.recipes = self.recipes.union(recipes_set)
        for i in recipes:
            self.nodes[u].type &= ~NodeType.NORMAL
            self.nodes[i].type |= NodeType.RECIPE

import copy

@dataclass
class State:
    pos: int
    path: List[int]
    nodetime: int
    hard_nodes: Dict[int, int]
    done_recipes: Set[int]
    done_devotees: Set[int]

    def _tuple(self):
        return (self.pos,
                self.nodetime,
                tuple(self.done_recipes),
                tuple(self.done_devotees))

    def __hash__(self) -> int:
        return hash(self._tuple())

    def __eq__(self, other: Any) -> bool:
        return isinstance(other, State) and (
            self.pos == other.pos and
            self.nodetime == other.nodetime and
            self.done_recipes == other.done_recipes and
            self.done_devotees == other.done_devotees
        )


def is_goal(graph: Graph, state: State) -> bool:
    return len(graph.devotee_recipes) == len(state.done_devotees)


def initial_state(graph: Graph, start: int) -> State:
    return State(
        pos=start,
        path=[start],
        nodetime=0,
        hard_nodes={x: 0 for x in graph.hard_nodes},
        done_recipes=set(),
        done_devotees=set()
    )


def transition_states(graph: Graph, state: State) -> List[State]:
    graph.time = graph.time + 1
    if NodeType.HARD in graph.nodes[state.pos].type:
        if state.nodetime < state.hard_nodes[state.pos]:
            new_state = copy.deepcopy(state)
            new_state.nodetime += 1
            new_state.path.append(state.pos)
            return [new_state]
        else:
            state.hard_nodes[state.pos] += 1

    new_states = []
    for edge in graph.nodes[state.pos].adj:
        if edge.last_crossing_time == 0 or graph.time > edge.last_crossing_time + edge.time_between_two_crossings: 
            neigh = edge.dst

            new_state = copy.deepcopy(state)
            new_state.pos = neigh
            new_state.nodetime = 0
            new_state.path.append(neigh)
            edge.last_crossing_time = graph.time
            
            if NodeType.RECIPE in graph.nodes[neigh].type:
                for higher_proirity_devotee, lower_proirity_devotee in graph.devotee_proirities:
                    if graph.devotee_recipes[higher_proirity_devotee].issubset(neigh) or (graph.devotee_recipes[lower_proirity_devotee].issubset(neigh) and new_state.done_devotees.issubset(higher_proirity_devotee)):
                        new_state.done_recipes.add(neigh)
                else:
                    new_state.done_recipes.add(neigh)

            if NodeType.DEVOTEE in graph.nodes[neigh].type:
                if graph.devotee_recipes[neigh].issubset(new_state.done_recipes):
                    new_state.done_devotees.add(neigh)

        new_states.append(new_state)

    return new_states

def read_input(inp: List[str]) -> Tuple[Graph, int]:
    inpt = iter(inp)
    n, m = map(int, next(inpt).split())
    graph = Graph(n)
    list_of_edges = [[int, int]]
    for i in range(m):
        u, v = map(int, next(inpt).split())
        graph.add_edge(u - 1, v - 1, 0)
        list_of_edges.append([u - 1, v - 1])

    h = int(next(inpt))
    for i in range(h):
        edge, t = map(int, next(inpt).split())
        graph.setas_loose_edge(list_of_edges, edge, t)
        
    start = int(next(inpt)) - 1
    
    s = int(next(inpt))
    list_of_devotees = [[int, [int]]]
    for i in range(s):
        p, _, *recipes = map(int, next(inpt).split())
        graph.add_devotee(p - 1, [x - 1 for x in recipes])

    t = int(next(inpt))
    devotee_priorities = [[int, int]]
    for i in range(t):
        devotee_priority = map(int, next(inpt).split())
        devotee_priorities.append(devotee_priority)

    graph.set_devotee_proirities(devotee_priorities)

    return (graph, start)

import itertools

def read_file(filename: str):
    global graph, start

    with open(filename, 'r', encoding='utf-8') as f:
        inp = [x.rstrip('\n') for x in f]

    graph, start = read_input(inp)


def unique_consecutive(lst: List[Any]) -> List[Any]:
    return [i for i, _ in itertools.groupby(lst)]

import time

TEST_REPEATS = 3


def run(search_alg: Callable[[Graph, State], Tuple[State, int]]):
    time_start = time.time()
    for _ in range(TEST_REPEATS):
        goal_state, num_visited = search_alg(graph, start)
    time_elapsed = (time.time() - time_start) / TEST_REPEATS

    if goal_state is None:
        print('No solution')
    else:
        print(*[x + 1 for x in goal_state.path], sep=' -> ')
        print('Path cost:', len(goal_state.path) - 1)
        print('Visited states:', num_visited)
        print('Average time:', time_elapsed)

def BFS(graph: Graph, start: int) -> Tuple[State, int]:
    state = initial_state(graph, start)
    if is_goal(graph, state):
        return state

    frontier: List[State] = []
    visited: Set[State] = set()
    frontier.append(state)
    
    while frontier:
        s = frontier.pop(0)
        if is_goal(graph, s):
            return s, len(visited)

        for next_state in transition_states(graph, s):
            if next_state in visited:
                continue
            if next_state in frontier:
                continue
            frontier.append(next_state)

        visited.add(s)

    return None, None

read_file(INPUT)
print(f'--- File: {INPUT} ---')
run(BFS)

def DLS_rec_impl(graph: Graph, state: State, visited: Set[State], limit: int, num_visited: int) -> Tuple[State, int]:
    if limit <= 0:
        return None, num_visited

    if is_goal(graph, state):
        return state, num_visited

    for next_state in transition_states(graph, state):
        if next_state in visited:
            continue

        visited.add(next_state)
        num_visited += 1

        res, num_visited = DLS_rec_impl(graph, next_state, visited, limit - 1, num_visited)
        visited.remove(next_state)

        if res is not None:
            return res, num_visited

    return None, num_visited


def DLS_rec(graph: Graph, start: int, depth: int) -> Tuple[State, int]:
    state = initial_state(graph, start)
    visited: set[State] = set()
    visited.add(state)
    return DLS_rec_impl(graph, state, visited, depth, 0)


def IDS(graph: Graph, start: int, max_depth: int = None) -> Tuple[State, int]:
    depth = 1
    all_num_visited = 0
    while True:
        if max_depth is not None and max_depth < depth:
            return None

        goal_state, num_visited = DLS_rec(graph, start, depth)
        all_num_visited += num_visited
        if goal_state is not None:
            return goal_state, all_num_visited
        depth += 1
read_file(INPUT)
print(f'--- File: {INPUT} ---')
run(IDS)


def heuristic(state: State) -> int:
    notdone_recipes = graph.recipes.difference(state.done_recipes)
    notdone_devotees = [k for k in graph.devotee_recipes if k not in state.done_devotees]
    return len(notdone_recipes.union(notdone_devotees))

import heapq
 

class MinHeap:
    def __init__(self, priority_func: Callable[[Any], int] = None):
        self._data: list[tuple[int, int, Any]] = []
        self._counter = itertools.count()
        self._func = None
        if callable(priority_func):
            self._func = priority_func

    def push(self, value: Any, priority: int = None):
        if priority is None and self._func is not None:
            priority = self._func(value)

        elem = (priority, next(self._counter), value)
        heapq.heappush(self._data, elem)

    def pop(self) -> Any:
        return heapq.heappop(self._data)[-1]

    def top(self) -> Any:
        return self._data[0][-1]

    def __bool__(self):
        return bool(self._data)

    def __iter__(self):
        for i in self._data:
            yield i[-1]

def AStar(graph: Graph, start: int, alpha: int = 1) -> Tuple[State, int]:
    state = initial_state(graph, start)
    if is_goal(graph, state):
        return state

    def h(state: State) -> int:
        return alpha * heuristic(state) + len(state.path)

    frontier = MinHeap(h)
    visited: set[State] = set()
    frontier.push(state)

    while frontier:
        s = frontier.pop()
        if is_goal(graph, s):
            return s, len(visited)

        for next_state in transition_states(graph, s):
            if next_state in visited:
                continue
            if next_state in frontier:
                continue
            frontier.push(next_state)

        visited.add(s)

    return None, None
from functools import partial

read_file(INPUT)
print(f'--- File: {INPUT} ---')
run(AStar)
run(partial(AStar, alpha=1.2))
run(partial(AStar, alpha=5))

test_cases = ['Inputs/input_0.txt', 'Inputs/input_1.txt', 'Inputs/input_2.txt']

for test in test_cases:
    read_file(test)
    print(f'=-=-=-=-=-=-=-= {test} =-=-=-=-=-=-=-=')
    print('\n--- BFS ---')
    run(BFS)
    print('\n--- IDS ---')
    run(IDS)
    print('\n--- A* ---')
    run(AStar)
    print('\n--- A* alpha=1 ---')
    run(partial(AStar, alpha=1))
    print('\n--- A* alpha=2 ---')
    run(partial(AStar, alpha=2))
    print('\n')
