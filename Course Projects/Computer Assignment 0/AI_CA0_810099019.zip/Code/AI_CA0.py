import pandas as pd
import matplotlib.pyplot as plt
import scipy.stats as stats
import time

# part 1, 2 codes
DataFrame = pd.read_csv('train.csv')
print(DataFrame.describe())
print(DataFrame.tail())
print(DataFrame.head())
print(DataFrame.info())

# part 3 codes
print(DataFrame.isnull().sum())
DataFrame = DataFrame.fillna(DataFrame.mean())
print(DataFrame.isnull().sum())

# part 5 codes
print(DataFrame['sex'].value_counts())
print(DataFrame[['relationship', 'sex']].value_counts((DataFrame.sex == 0) & (DataFrame.relationship == 'Husband')))

# part 6 codes
print(DataFrame[['age', 'race', 'workclass']].value_counts((DataFrame.age > 30) & (DataFrame.race == 'Black') & (DataFrame.workclass == 'Private')))

# part 7 codes
start = time.time()
print(DataFrame[DataFrame['education'].eq('Bachelors')]["hours-per-week"].mean())
end = time.time()
print("Time token to measure mean(with vectorization) is: " + str(end - start))

# part 8 codes
start = time.time()
number_of_Bachelors = 0
sum_of_Bachelors_hours_per_week = 0
for row in DataFrame.index:
    if DataFrame['education'][row] == 'Bachelors':
        sum_of_Bachelors_hours_per_week = sum_of_Bachelors_hours_per_week + DataFrame["hours-per-week"][row]
        number_of_Bachelors = number_of_Bachelors + 1
print(sum_of_Bachelors_hours_per_week / number_of_Bachelors)
end = time.time()
print("Time token to measure mean(without vectorization) is: " + str(end - start))

# part 9 codes
DataFrame.hist()
plt.show()

# part 10 codes
normalized_DataFrame = (DataFrame - DataFrame.mean()) / DataFrame.std()
normalized_DataFrame.hist()
plt.show()

# part 11 codes
mean_salary_higher_than_50K = DataFrame[DataFrame['salary'].eq('>50K')]['fnlwgt'].mean()
mean_salary_lower_than_50K = DataFrame[DataFrame['salary'].eq('<=50K')]['fnlwgt'].mean()
std_salary_higher_than_50K = DataFrame[DataFrame['salary'].eq('>50K')]['fnlwgt'].std()
std_salary_lower_than_50K = DataFrame[DataFrame['salary'].eq('<=50K')]['fnlwgt'].std()

sorted_salary_higher_than_50K = sorted(DataFrame[DataFrame['salary'].eq('>50K')]['fnlwgt'])
pdf_higher_than_50K = stats.norm.pdf(sorted_salary_higher_than_50K, mean_salary_higher_than_50K, std_salary_higher_than_50K)

sorted_salary_lower_than_50K = sorted(DataFrame[DataFrame['salary'].eq('<=50K')]['fnlwgt'])
pdf_lower_than_50K = stats.norm.pdf(sorted_salary_lower_than_50K, mean_salary_lower_than_50K, std_salary_lower_than_50K)

plt.plot(sorted_salary_higher_than_50K, pdf_higher_than_50K)
plt.plot(sorted_salary_lower_than_50K, pdf_lower_than_50K)
plt.legend(['Higher than 50K', 'Less than 50K'])
plt.show()

# part 12 codes
Test_DataFrame = pd.read_csv('test.csv')
for row in Test_DataFrame.index:
    if (100000 < Test_DataFrame['fnlwgt'][row] & Test_DataFrame['fnlwgt'][row] < 300000):
        Test_DataFrame['salary'][row] = '>50K'
    else:
        Test_DataFrame['salary'][row] = '<=50K'
Test_DataFrame.to_csv('test_output.csv')
