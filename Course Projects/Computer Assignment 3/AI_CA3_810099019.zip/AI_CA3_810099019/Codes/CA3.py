import numpy as np
import pandas as pd
from tensorflow.keras.applications.vgg16 import VGG16, preprocess_input
from tensorflow.keras.preprocessing.image import load_img, img_to_array
from tensorflow.keras.models import Model

# load the model
model = VGG16(include_top=False)

# restructure the model
model = Model(inputs=model.inputs, outputs=model.get_layer('block5_conv3').output)

# summary
print(model.summary())

# Extract Features
features = []
labels = []
directory = 'flower_images//'
images = pd.read_csv(directory + 'flower_labels.csv')
for index, image in images.iterrows():
    image_path = directory + image['file']
    
    # load the image
    img = load_img(image_path, target_size=(224, 224))
    # convert pixel to numpy array
    img = img_to_array(img)
    # reshape the image for the model
    img = img.reshape((1, img.shape[0], img.shape[1], img.shape[2]))
    # preprocess the image
    img = preprocess_input(img)
    # extract features
    feature = model.predict(img, verbose=0)
    # store feature
    features.append(feature.flatten())

    labels.append(image['label'])

features = np.array(features)


#KMeans for K = 6, 7, 8, 9, 10, 11, 12 with their Silhoutte scores
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
import matplotlib.cm as cm
import matplotlib.pyplot as plt
from sklearn.metrics import homogeneity_score, silhouette_samples, silhouette_score

range_num_of_clusters = [6, 7, 8, 9, 10, 11, 12]

for num_of_clusters in range_num_of_clusters:
    fig, ax1 = plt.subplots()
    fig.set_size_inches(9, 7)
    ax1.set_xlim([-1, 1])
    ax1.set_ylim([0, len(features) + (num_of_clusters + 1) * 10])

    reduced_features = PCA(n_components=2).fit_transform(features)
    kmeans = KMeans(n_clusters=num_of_clusters)
    kmeans.fit(reduced_features)

    sil_score_avg = silhouette_score(features, kmeans.labels_)
    print("cluster num :", num_of_clusters, " silhouette score :", sil_score_avg)
    sample_score = silhouette_samples(features, kmeans.labels_)

    lowerbound_y = 10
    for i in range(num_of_clusters):
        cluster_score = sample_score[kmeans.labels_ == i]
        cluster_score.sort()
        cluster_num = cluster_score.shape[0]
        upperbound_y = lowerbound_y + cluster_num

        color = cm.nipy_spectral(float(i) / num_of_clusters)
        ax1.fill_betweenx(np.arange(lowerbound_y, upperbound_y), 0, cluster_score, facecolor=color,
                          edgecolor=color, alpha=0.7)

        ax1.text(-0.05, lowerbound_y + 0.5 * cluster_num, str(i))
        lowerbound_y = upperbound_y + 10

    ax1.set_title("The silhouette plot for the various clusters")
    ax1.set_xlabel("The silhouette coefficient values")
    ax1.set_ylabel("Cluster label")
    ax1.axvline(x=sil_score_avg, color="red", linestyle="--")
    ax1.set_yticks([])
    ax1.set_xticks([-0.2, -0.1, 0, 0.2, 0.4, 0.6, 0.8, 1])

    plt.suptitle(
        "Silhouette analysis for KMeans clustering on sample data with num_of_clusters = %d"
        % num_of_clusters,
        fontsize=14,
        fontweight="bold",
    )

    plt.show()

#KMeans for K = 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 with their Homogeneity scores
range_num_of_clusters = [5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]

for num_of_clusters in range_num_of_clusters:
    reduced_features = PCA(n_components=21).fit_transform(features)
    kmeans = KMeans(n_clusters=num_of_clusters)
    kmeans.fit(reduced_features)
    predicted_labels = kmeans.labels_
    selected_centers = kmeans.cluster_centers_
    
    homogeneity = homogeneity_score(labels, predicted_labels)
    silhouette = silhouette_score(reduced_features, predicted_labels)

    fig, ax1 = plt.subplots(figsize=(10, 6))

    ax1.scatter(reduced_features[:, 0], reduced_features[:, 1], c=predicted_labels, cmap='viridis', s=50, alpha=0.5, label='Clustered Data Points')
    ax1.scatter(selected_centers[:, 0], selected_centers[:, 1], c='red', marker='x', s=200, label='Cluster Centers')
    ax1.set_title(f'Clustering Results (PCA)\nHomogeneity Score: {homogeneity:.2f}, Silhouette Score: {silhouette:.2f}')
    ax1.set_xlabel('dim 1')
    ax1.set_ylabel('dim 2')
    ax1.legend()

    plt.show()


# DBSCAN for min points = 2 and epsilon = 50, 60, 70, 80, 90, 100, 110, 120, 130, 140, 150
from sklearn.cluster import DBSCAN

epsilon = 80
min_samples = 2
reduced_features = PCA(n_components=2).fit_transform(features)
dbscan_predicted_labels = DBSCAN(eps=epsilon, min_samples=min_samples).fit_predict(reduced_features)
print(dbscan_predicted_labels)
print(f"homogeneity score of kmeans: {homogeneity_score(labels, dbscan_predicted_labels)}")
print(f"silhouette score of kmeans: {silhouette_score(features, dbscan_predicted_labels)}")

silhouette_scores = []
DBSCAN_EPS_RANGE = [50, 60, 70, 80, 90, 100, 110, 120, 130, 140, 150]
DBSCAN_EPS_RANGE = np.array(DBSCAN_EPS_RANGE)
num_of_clusters = []

for eps in DBSCAN_EPS_RANGE:
    reduced_features = PCA(n_components=2).fit_transform(features)
    dbscan_predicted_clusters = DBSCAN(eps=eps, min_samples=min_samples).fit_predict(reduced_features)
    silhouette_score_val = silhouette_score(features, dbscan_predicted_clusters)
    silhouette_scores.append(silhouette_score_val)
    
    num_of_detected_clusters = len(set(dbscan_predicted_clusters)) - (1 if -1 in dbscan_predicted_clusters else 0)
    num_of_clusters.append(num_of_detected_clusters)
    
    print(f"Silhouette score for epsilon={eps}: {silhouette_score_val}")
    print(f"Number of clusters for epsilon={eps}: {num_of_detected_clusters}")
    print(f"Homogeneity score for epsilon={eps}: {homogeneity_score(labels, dbscan_predicted_clusters)}")

fig, ax1 = plt.subplots()

color = 'tab:red'
ax1.set_xlabel('Epsilon')
ax1.set_ylabel('Silhouette Score', color=color)
ax1.plot(DBSCAN_EPS_RANGE, silhouette_scores, marker='o', color=color)
ax1.tick_params(axis='y', labelcolor=color)

ax2 = ax1.twinx()  
color = 'tab:blue'
ax2.set_ylabel('Number of Clusters', color=color)  
ax2.plot(DBSCAN_EPS_RANGE, num_of_clusters, marker='x', color=color)
ax2.tick_params(axis='y', labelcolor=color)

fig.tight_layout()  
plt.title('Silhouette Score and Number of Clusters vs. Epsilon')
plt.xlabel('Epsilon')
plt.grid(True)
plt.show()
