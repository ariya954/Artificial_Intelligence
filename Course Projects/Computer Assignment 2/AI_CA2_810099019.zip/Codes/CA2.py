import random
import csv

# Number of individuals in each generation 
POPULATION_SIZE = 400

# types of available snakcs 
SNACKS = []

# available weight of each snack
Available_Weight_of_Snacks = []

# value of each snack
Values_of_Snacks = []

def read_snacks_from(File):
        with open(File, mode ='r')as file:
                csvFile = csv.reader(file)
                for lines in csvFile:
                        if(lines == ['Snack', 'Available Weight', 'Value']):
                                continue
                        SNACKS.append(lines[0])
                        Available_Weight_of_Snacks.append(int(lines[1]))
                        Values_of_Snacks.append(int(lines[2]))
        

class Individual(object): 
	''' 
	Class representing individual in population 
	'''
	def __init__(self, chromosome): 
		self.chromosome = chromosome 
		self.fitness = self.calculate_fitness() 

	def apply_mutation(self): 
		''' 
		swaping two random genes of a chromosome for mutation by the probablity of the mutation 
		'''

		Mutation_Probablity = 0.8
		if(random.uniform(0, 1) < Mutation_Probablity):
			index_1 = random.randint(0, len(self.chromosome) - 1)
			index_2 = random.randint(0, len(self.chromosome) - 1)
			copy = self.chromosome[index_1]
			self.chromosome[index_1] = self.chromosome[index_2]
			self.chromosome[index_2] = copy
			
	@classmethod
	def create_gnome(self): 
		''' 
		create chromosome or string of genes, which are the weights taken from each snack 
		'''
		global SNACKS 
		return [random.randint(0, Available_Weight_of_Snacks[snack]) for snack in range(len(SNACKS))] 

	def crossover_with(self, par2): 
		''' 
		Perform crossover and produce new offspring 
		'''

		# chromosome for offspring 
		child_chromosome = [] 
		for gp1, gp2 in zip(self.chromosome, par2.chromosome):	 

			# random probability 
			prob = random.random() 

			# if prob is less than 0.5, insert gene 
			# from parent 1 otherwise insert gene from parent 2 
			if prob < 0.5: 
				child_chromosome.append(gp1) 
			else: 
				child_chromosome.append(gp2) 


		# create new Individual(offspring) using 
		# generated chromosome for offspring 
		return Individual(child_chromosome) 

	def calculate_fitness(self): 
		''' 
		Calculate fitness score, it is the number representing how best the chromosome fits by considering the constraints of the problem
		'''

		total_value_of_snacks = 0
		total_weight_of_snacks = 0
		total_number_of_snacks = 0
    
		global SNACKS, Values_of_Snacks, Available_Weight_of_Snacks
		for snack in range(len(SNACKS)):
			total_value_of_snacks += ((Values_of_Snacks[snack] * self.chromosome[snack]) / Available_Weight_of_Snacks[snack])
			total_weight_of_snacks += self.chromosome[snack]
			if(self.chromosome[snack] > 0):
				total_number_of_snacks += 1

		if(total_weight_of_snacks > Maximum_Total_Weight_of_Chosen_Snacks):
			return Maximum_Total_Weight_of_Chosen_Snacks - total_weight_of_snacks

		if(total_value_of_snacks < Minimum_Total_Value_of_Chosen_Snacks):
			return total_value_of_snacks - Minimum_Total_Value_of_Chosen_Snacks

		if(total_number_of_snacks < Minimum_Number_of_Types_of_Chosen_Snacks):
			return total_number_of_snacks - Minimum_Number_of_Types_of_Chosen_Snacks                        

		if(total_number_of_snacks > Maximum_Number_of_Types_of_Chosen_Snacks):
			return Maximum_Number_of_Types_of_Chosen_Snacks - total_number_of_snacks                
                   
		for snack in range(len(SNACKS)):
			if(self.chromosome[snack] > Available_Weight_of_Snacks[snack]):
				return -(self.chromosome[snack] - Available_Weight_of_Snacks[snack])

		return (total_value_of_snacks * 30) + (total_number_of_snacks * 20) - (total_weight_of_snacks * 10)

# Driver code 
def main(): 
	global POPULATION_SIZE

	global Minimum_Total_Value_of_Chosen_Snacks,\
               Maximum_Total_Weight_of_Chosen_Snacks,\
               Minimum_Number_of_Types_of_Chosen_Snacks,\
               Maximum_Number_of_Types_of_Chosen_Snacks

	Minimum_Total_Value_of_Chosen_Snacks = int(input("Please Enter the minimum total value of chosen snacks\n"))
	Maximum_Total_Weight_of_Chosen_Snacks = int(input("Please Enter the maximum total weight of chosen snacks\n"))
	Minimum_Number_of_Types_of_Chosen_Snacks = int(input("Please Enter the minimum number of types of chosen snacks\n"))
	Maximum_Number_of_Types_of_Chosen_Snacks = int(input("Please Enter the maximum number of types of chosen snacks\n"))	

	#current generation 
	generation = 1
	
	population = []

	read_snacks_from('snacks.csv')

	# create initial population 
	for _ in range(POPULATION_SIZE): 
				gnome = Individual.create_gnome() 
				population.append(Individual(gnome))

	Number_of_rounds_of_this_genetic_algorithm = 300

	for round in range(Number_of_rounds_of_this_genetic_algorithm):
                
		# sort the population in decreasing order of fitness score 
		population = sorted(population, key = lambda x:x.fitness, reverse=True) 
            
		# generate new offsprings for new generation 
		new_generation = [] 

		# Perform Elitism, that mean 10% of fittest population 
		# goes to the next generation 
		s = int((10*POPULATION_SIZE)/100) 
		new_generation.extend(population[:s]) 

		# From 90% of fittest population, Individuals 
		# will mate to produce offspring 
		s = int((90*POPULATION_SIZE)/100) 
		for _ in range(s):                        
			parent1 = random.choice(population[:s]) 
			parent2 = random.choice(population[:s]) 
			child = parent1.crossover_with(parent2)
			child.apply_mutation()
			new_generation.append(child)
            
		population = new_generation 

		print("Generation {} of answers:\tWeights taken from each snack: {}\tFitness score: {}".\
			format(generation, 
			population[0].chromosome, 
			population[0].fitness)) 

		generation += 1

	
	print("Generation {} of answers:\tWeights taken from each snack: {}\tFitness score: {}".\
		format(generation, 
		population[0].chromosome, 
		population[0].fitness))

if __name__ == '__main__': 
	main() 
